const app = require("./");

app.listen(6969, ( ()=> {
    console.log("App is listening on port " + 6969)
}));