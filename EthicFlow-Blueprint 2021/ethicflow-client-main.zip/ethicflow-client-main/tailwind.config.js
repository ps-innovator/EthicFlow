module.exports = {
    theme: {
        extend: {
            spacing: {
                '72': '18rem',
                '80': '20rem',
                '96': '24rem',
            }
        }
    }
};